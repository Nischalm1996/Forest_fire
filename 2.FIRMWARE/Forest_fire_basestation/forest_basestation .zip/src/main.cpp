#include <Arduino.h>
#include "displayMenu1602.h"

displayMenu1602 disp;
void setup()
{
   put your setup code here, to run once:
  disp.begin();
}

void loop()
{
  // put your main code here, to run repeatedly:
  disp.runMenu();
}